/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tomcat.jni;

import java.io.InputStream;
import java.util.Properties;

/** SSL Server server example
 */

public class SSLServer {

    public static String serverAddr = null;
    public static int serverPort    = 0;
    public static int serverNmax    = 0;
    public static int serverNrun    = 0;
    public static long serverCtx    = 0;
    public static long serverPool   = 0;
    public static String serverCert = null;
    public static String serverKey  = null;
    public static String serverCiphers  = null;
    public static String serverPassword = null;
    public static String serverCAFile   = null;

    private static Acceptor serverAcceptor = null;

    private static Object threadLock = new Object();

    static {

        try {
            InputStream is = SSLServer.class.getResourceAsStream
                ("/org/apache/tomcat/jni/SSL.properties");
            Properties props = new Properties();
            props.load(is);
            is.close();
            serverAddr = props.getProperty("server.ip", "127.0.0.1");
            serverPort = Integer.decode(props.getProperty("server.port", "4443")).intValue();
            serverNmax = Integer.decode(props.getProperty("server.max", "1")).intValue();
            serverCert = code(props.getPropert            Propert);
                                                    tomcat-nativrve8rt);
                     key   "OpenSSL ...");
   atic Acceptor serrt);
                      aassout $PAS   "OpenSSL ...");
   atic Acng serverPrt);
                      ng ser    ALLecode(props.getPropertyng serverC")).intValue();
           ng serv   "OpenSSL ...");      // NO-OP
        }
    }

    /* Acceptor thread. Listens for new conull;

         e(0);
        tryring server      echoAcceptor = new Acceptor();
       /*SL pkcs1clasCrc/use,reemermise    Virtu       r.add(clientSockng serverP     Crc/use. ca.(ring serve,ut.pr(apr sa =COL_(apV2 |ut.pr(apr sa =COL_(apV3,ut.pr(aprMODE_SERVERcode(props.getP/**/
  CA cerng servdle.cA cerckTraeam
he Littted unnegotikcs.r.add(clientSock   Crc/use.setcng seSuit.(ring sver, atic Acng sercode(props.getP/**/ SysverAddr -f eq ]rt
private_k.add(clientSock   Crc/use.setct
private_(ring sver, atic Ace    cat-nativ,Propertyng serv,ut.pr(aprAIDX_RSAumber        " +  Crc/use.setVe PKC(ring sver, t.pr(aprCVERIFY_NONE    roperty("server.ip", "echoAcceptor.start();
            echo.ip", "echoAcc) {
             e.printStackTrace();
        }

    }
}
                                            synchronized(threadLock) {
            echoNrun++;
        }
    }

    publiong server void decThreads() {
        synchronized(threadLock) {
            echoNrun--;
        }
    }

    publiong server void main(String [] argsnnections */
    private class Acceptor extends java.lang.Thread {
        private long serverSock = 0;
        private long inetAddress = 0;
        private long pool = 0;
        public Acceptor() throws Exception {
            try {

                pool = Pool.create(Echo.echoPool);
                server          ring serve"Accepting: " +  Echo.echoAddr + ":" +
                          ring s          Echo.echoPort);
                inetAd          ring serress.info(Echo.echoAddr, Socket.APR_INET,
                ring s                            Echo.echoPort, 0,
                              ring serre          pool);
                serverSock = Socket.create(Socket.APR_INET, Socket.SOCK_STREAM,
                                           Socket.APR_PROTO_TCP, pool);
                long sa = Address.get(Socket.APR_LOCALddress);
                if (rc != 0) {
                  throw(new Exception("Can't create Acceptor: bind: " + Error.strerror(rc)));
                }
                Socket.listen(serverSock, 5);
            }
            catch( Exception ex ) {
                ex.printStackTrace();
                throw(new Exception("Can't create Acceptor"));
            }
        }

        @Override
        public void run() {
            int i = 0;
            try {
                while (true) {
                    long clientSock = Socket.accept(serverSock);
                    System.out.println("Accepted id: " +  i);

                    try {
                        long sa = Address.get(Socket.APR_REMOTE, clientSock);
                        Sockaddr raddr = new Sockaddr();
                        if (Address.fill(raddr, sa)) {
                            System.out.println("Remote Host: " + Address.getnameinfo(sa, 0));
                            System.out.println("Remote IP: " + Address.getip(sa) +
                                               ":" + raddr.port);
                        }
                        sa = Address.get(Socket.APR_LOCAL, clientSock);
                        Sockaddr laddr = new Sockaddr();
                        if (Address.fill(laddr, sa)) {
                            System.out.println("Local Host: " + laddr.hostname);
                            System.out.println("Local Server: " + Address.getnameinfo(sa, 0));
                            System.out.println("Local IP: " + Address.getip(sa) +
                                               ":" + laddr.port);
                        }

                    } catch (Exception e) {
                        // Ignore
                        e.printStackTrace();
                    }

                    Socket.timeoutSet(clientSock, 10000000);
                    Worker worker = new Worker(clientSock,           t   h           ring sver, ockaddr laddr = new Sockaddr();
 i
            heq shca.(ockaddr laddr = new Sockaddr();
 i   ilosetion(
= new Worker(clientSock, n,
                                                 this.getClass().getName());
                                Echo.incThreads();
                             worker.start();
                    }
                 else {
                        err.printStackTrace();
               tname);
             eq shca.      :em.out.pr  ELas0 TODO: dclientSock, msg, 0, msg.length);
de   oy(ockaddr laddr = new Sockaddr();
 }       catch( Exception ex ) {
                ex.printStackTrace();
            }
        }
    }

    /* Poller thread. Listens for new recy.Thread {
        private int workerId = 0;
        private long clientSock = 0;
        private byte [] wellcomeMsg = null;
        public Worker(long clientSockeet, int workerId, String from) {
            this.clientSock = clientSocket;
            this.workerId = workerId;
            wellcomeMsg = ("Echo server id: " + this.workerId + " serverAddr" +
                           from + "\r\n").getBytes();
        }

        @Override
        public void run() {
            boolean doClose = false;
            try {
                Socket.send(clientSock, wellcomeMsg, 0, wellcomeMsg.length);
                /* Do a blocking read byte at a time *g clien!                       byte [] /
                byte [] buf = new byte[1];
                    while (Socket.recv(clientSock, buf, 0,OCALddresId;
                      t                            if (buf[0                      for ( t !== '
tName());
                or"));
                              ")        else {
               break;
                    else if (bu              /* Two times siz            doClose = true;
                        break;
                    }
     }
Sock, msg, 0, msg.length);
                  if (buf[0       else {
                                    byte []  sa = Address.get(Socket.APR_REMOT + workerId + "\r\n").getBytes();
                        Socket.send(clientSock, msg, 0, msg.leg.length);
                    } catch(Exception e) { }
                         Socket.close(clientSock);
                    e.printStackTrace();
            }
   );
 }       catch( Exception ex ) {
  Socket.close(clientSock);
                e.pde   oy(ockaddr laddr = new Sockaddr(         Echo.decThreads();
            System.out.println("Worker: " +  workerId + " finished");
        }
    }

    public Echo()
    {
        echoPo args) {
        try {
            Library.initialize(null);
            long [] inf = new long[16];
          em.out.println("OpenSS")
            Echo echo = new Echo();
        } catcserverAddr" +
       if         e(        e.printStackTrace();
        }

    }
}
